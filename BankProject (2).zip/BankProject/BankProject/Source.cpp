/*
Christian Blanchette

This program will take the user inputs for their current account balance, monthly interest rate, monthly deposits and how far they want the program to calculate to, and use the input to create 
a forecast of the users bank account, with a yearly print out of the current balance and how much interest was made from that year. 

6/6/2021
*/
#include<iostream>
#include<string>
#include"Banking.h"

using namespace std;
/*
declares a banking object, and calls the input and output 
Has no parameters, just exists to call methods
does not return anything as it is the main file and sits at the top of the call heirarchy.
*/
int main() {

	 Banking myAccount;			//declare a variable using the class we created
	 myAccount.UserInput();		//Call the input function so that it may be collected for use 
	 myAccount.Output();		//Utilize the output function 

}